﻿// ==========================================
// KOD BACKEND KOKURIKULUM & KEHADIRAN (Kokurikulum.gs)
// PORTAL DIGITAL SK SOOK 2026
// PENGURUSAN UNIT BERUNIFORM, KELAB & PERSATUAN, 1M1S
// ==========================================

// --------------------------------------------------------------------------
// 1. SISTEM PENGECAMAN KATEGORI & TAB SHEET GOOGLE SHEETS
// --------------------------------------------------------------------------

// Pengecaman Kod Warna Tab Google Sheets (RGB -> HSL)
// 1. Unit Beruniform: Tab Kuning (Yellow)
// 2. Kelab & Persatuan: Tab Hijau (Green)
// 3. 1M1S: Tab Oren (Orange)
function klasifikasiWarnaTab(colorHex) {
  if (!colorHex) return null;
  var hex = String(colorHex).toLowerCase().replace('#', '').trim();
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  if (hex.length !== 6) return null;

  var r = parseInt(hex.substring(0, 2), 16);
  var g = parseInt(hex.substring(2, 4), 16);
  var b = parseInt(hex.substring(4, 6), 16);

  var rNorm = r / 255, gNorm = g / 255, bNorm = b / 255;
  var max = Math.max(rNorm, gNorm, bNorm), min = Math.min(rNorm, gNorm, bNorm);
  var h = 0, s = 0, l = (max + min) / 2;

  if (max !== min) {
    var d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case rNorm: h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0); break;
      case gNorm: h = (bNorm - rNorm) / d + 2; break;
      case bNorm: h = (rNorm - gNorm) / d + 4; break;
    }
    h = h * 60; // Sudut Hue 0 - 360 darjah
  }

  // Pengelasan mengikut Hue:
  // Oren (Orange): Hue 14Â° hingga 44Â° -> 1M1S
  if (h >= 14 && h < 44 && s > 0.20) {
    return "1M1S";
  }

  // Kuning (Yellow): Hue 44Â° hingga 72Â° -> Unit Beruniform
  if (h >= 44 && h < 72 && s > 0.20) {
    return "BERUNIFORM";
  }

  // Hijau (Green): Hue 72Â° hingga 175Â° -> Kelab & Persatuan
  if (h >= 72 && h <= 175 && s > 0.18) {
    return "KELAB";
  }

  return null;
}

// Pengecaman Pintar Kategori Tab Mengikut Warna Tab & Kata Kunci Nama Tab
function kenalPastiKategoriTab(sheet) {
  var nama = sheet.getName().trim();
  var namaUpper = nama.toUpperCase();

  // Tab-tab sistem yang dikecualikan
  var tabSistem = [
    "PENGGUNA", "RPH_GURU", "TAKWIM", "DSKP", "DSKP_PPKI", 
    "LAPORAN_BERTUGAS", "LAPORAN_KOKUM", "SEMAKAN_RPH", "DATABASE", "KEHADIRAN", "INDEX"
  ];
  if (tabSistem.includes(namaUpper)) return null;

  // 1. Keutamaan Pertama: Warna Tab Google Sheets
  try {
    var tabColor = sheet.getTabColor();
    if (tabColor) {
      var katWarna = klasifikasiWarnaTab(tabColor);
      if (katWarna) return katWarna;
    }
  } catch (e) {
    console.warn("Ralat semak getTabColor: " + e.message);
  }

  // 2. Keutamaan Kedua: Pengecaman Berdasarkan Kata Kunci Nama Tab
  if (namaUpper.includes("PENGAKAP") || namaUpper.includes("TKRS") || namaUpper.includes("BSMM") || 
      namaUpper.includes("PUTERI") || namaUpper.includes("KADET") || namaUpper.includes("BERUNIFORM") || 
      namaUpper.includes("PPIM") || namaUpper.includes("BULAN SABIT") || namaUpper.includes("PANDU") || 
      namaUpper.includes("UNIFORM")) {
    return "BERUNIFORM";
  }

  if (namaUpper.includes("1M1S") || namaUpper.includes("BOLA") || namaUpper.includes("TAKRAW") || 
      namaUpper.includes("BADMINTON") || namaUpper.includes("OLAHRAGA") || namaUpper.includes("FUTSAL") || 
      namaUpper.includes("JARING") || namaUpper.includes("PING PONG") || namaUpper.includes("CATUR") || 
      namaUpper.includes("HOKI") || namaUpper.includes("SUKAN") || namaUpper.includes("PERMAINAN")) {
    return "1M1S";
  }

  if (namaUpper.includes("KELAB") || namaUpper.includes("PERSATUAN") || namaUpper.includes("STEM") || 
      namaUpper.includes("DOKTOR") || namaUpper.includes("BAHASA") || namaUpper.includes("KESENIAN") || 
      namaUpper.includes("KEBUDAYAAN") || namaUpper.includes("BUDAYA") || namaUpper.includes("SENI") || namaUpper.includes("AGAMA") || namaUpper.includes("ISLAM") || 
      namaUpper.includes("SPBT") || namaUpper.includes("RUKUN NEGARA") || namaUpper.includes("ROBOTIK")) {
    return "KELAB";
  }

  return null;
}

// Senarai Lalai Rasmi Unit Kokurikulum SK Sook (Fallback Pintar)
var SENARAI_DEFAULT_KOKUM = {
  "BERUNIFORM": [
    { id: "Pengakap Kanak-Kanak", nama: "Pengakap Kanak-Kanak", warna: "Kuning" },
    { id: "Tunas Kadet Remaja Sekolah", nama: "Tunas Kadet Remaja Sekolah (TKRS)", warna: "Kuning" },
    { id: "Bulan Sabit Merah Malaysia", nama: "Bulan Sabit Merah Malaysia (BSMM)", warna: "Kuning" },
    { id: "Pandu Puteri Tunas", nama: "Pandu Puteri Tunas", warna: "Kuning" },
    { id: "Pergerakan Puteri Islam", nama: "Pergerakan Puteri Islam Malaysia (PPIM)", warna: "Kuning" }
  ],
  "KELAB": [
    { id: "Persatuan Bahasa Melayu", nama: "Persatuan Bahasa Melayu", warna: "Hijau" },
    { id: "Persatuan Bahasa Inggeris", nama: "Persatuan Bahasa Inggeris", warna: "Hijau" },
    { id: "Kelab STEM & Sains", nama: "Kelab STEM & Sains", warna: "Hijau" },
    { id: "Persatuan Pendidikan Islam", nama: "Persatuan Pendidikan Islam", warna: "Hijau" },
    { id: "Kelab Doktor Muda", nama: "Kelab Doktor Muda", warna: "Hijau" },
    { id: "Kelab Kesenian & Kebudayaan", nama: "Kelab Kesenian & Kebudayaan", warna: "Hijau" }
  ],
  "1M1S": [
    { id: "Kelab Bola Sepak", nama: "Kelab Bola Sepak / Futsal", warna: "Oren" },
    { id: "Kelab Bola Jaring", nama: "Kelab Bola Jaring", warna: "Oren" },
    { id: "Kelab Sepak Takraw", nama: "Kelab Sepak Takraw", warna: "Oren" },
    { id: "Kelab Badminton", nama: "Kelab Badminton", warna: "Oren" },
    { id: "Kelab Olahraga", nama: "Kelab Olahraga & Merentas Desa", warna: "Oren" }
  ]
};

// Fungsi Utama: Mengimbas & Menyenaraikan Semua Tab Mengikut 3 Kategori Utama
function getKategoriDanUnitKokum() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheets = ss.getSheets();

    var hasil = {
      "BERUNIFORM": [],
      "KELAB": [],
      "1M1S": []
    };

    for (var i = 0; i < sheets.length; i++) {
      var sh = sheets[i];
      var namaTab = sh.getName().trim();
      if (namaTab.toUpperCase().includes("PPKI")) continue;
      var kat = kenalPastiKategoriTab(sh);

      if (kat && hasil[kat]) {
        var labelWarna = kat === "BERUNIFORM" ? "Kuning" : (kat === "KELAB" ? "Hijau" : "Oren");
        hasil[kat].push({
          id: namaTab,
          nama: namaTab,
          warna: labelWarna
        });
      }
    }

    // Jika spreadsheet belum mengandungi tab khusus bagi sesuatu kategori, gunakan senarai piawai
    for (var k in SENARAI_DEFAULT_KOKUM) {
      if (!hasil[k] || hasil[k].length === 0) {
        hasil[k] = SENARAI_DEFAULT_KOKUM[k];
      }
    }

    return hasil;
  } catch (err) {
    console.error("Ralat imbas tab kokum: " + err.message);
    return SENARAI_DEFAULT_KOKUM;
  }
}

// Alias untuk keserasian panggilan sedia ada
function getSenaraiTabKokum() {
  return getKategoriDanUnitKokum();
}

function getSenaraiUnitKokumWeb() {
  return getKategoriDanUnitKokum();
}

// ==========================================================================
// PENGURUSAN UNIT KOKURIKULUM PPKI (PENDIDIKAN KHAS MASALAH PEMBELAJARAN)
// ==========================================================================
var SENARAI_DEFAULT_KOKUM_PPKI = {
  "BERUNIFORM": [
    { id: "PPKI PENGAKAP", nama: "PPKI PENGAKAP", warna: "Kuning" }
  ],
  "1M1S": [
    { id: "PPKI BADMINTON", nama: "PPKI BADMINTON", warna: "Oren" }
  ],
  "KELAB": [
    { id: "PPKI SENI BUDAYA", nama: "PPKI SENI BUDAYA", warna: "Hijau" }
  ]
};

// Imbas Google Sheets Khusus Bagi Unit Kokurikulum PPKI
function getKategoriDanUnitKokumPpki() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheets = ss.getSheets();

    var hasil = {
      "BERUNIFORM": [],
      "KELAB": [],
      "1M1S": []
    };

    for (var i = 0; i < sheets.length; i++) {
      var sh = sheets[i];
      var namaTab = sh.getName().trim();
      var namaUpper = namaTab.toUpperCase();

      if (namaUpper.includes("PPKI")) {
        if (namaUpper.includes("PENGAKAP") || namaUpper.includes("UNIFORM") || namaUpper.includes("BERUNIFORM")) {
          hasil["BERUNIFORM"].push({ id: namaTab, nama: namaTab, warna: "Kuning" });
        } else if (namaUpper.includes("BADMINTON") || namaUpper.includes("SUKAN") || namaUpper.includes("1M1S") || namaUpper.includes("PERMAINAN")) {
          hasil["1M1S"].push({ id: namaTab, nama: namaTab, warna: "Oren" });
        } else if (namaUpper.includes("SENI") || namaUpper.includes("BUDAYA") || namaUpper.includes("KELAB") || namaUpper.includes("PERSATUAN")) {
          hasil["KELAB"].push({ id: namaTab, nama: namaTab, warna: "Hijau" });
        }
      }
    }

    if (hasil["BERUNIFORM"].length === 0) hasil["BERUNIFORM"] = SENARAI_DEFAULT_KOKUM_PPKI["BERUNIFORM"];
    if (hasil["1M1S"].length === 0) hasil["1M1S"] = SENARAI_DEFAULT_KOKUM_PPKI["1M1S"];
    if (hasil["KELAB"].length === 0) hasil["KELAB"] = SENARAI_DEFAULT_KOKUM_PPKI["KELAB"];

    return hasil;
  } catch (err) {
    console.error("Ralat imbas tab kokum PPKI: " + err.message);
    return SENARAI_DEFAULT_KOKUM_PPKI;
  }
}

function getSenaraiTabKokumPpki() {
  return getKategoriDanUnitKokumPpki();
}

// --------------------------------------------------------------------------
// 2. PENGAMBILAN DATA MURID & STATUS KEHADIRAN SEMASA (READ)
// --------------------------------------------------------------------------

// Helper: Cari Lajur Minggu / Perjumpaan Pintar ("MINGGU 1", "M1", "PERJUMPAAN 1", "P1", dsb.)
function cariLajurMinggu(headerBaris, mingguKe) {
  if (!headerBaris || !mingguKe) return -1;
  var numStr = String(mingguKe).replace(/\D/g, '') || String(mingguKe).trim();
  
  var corakCari = [
    "MINGGU " + numStr,
    "M" + numStr,
    "M " + numStr,
    "PERJUMPAAN " + numStr,
    "P" + numStr,
    "P " + numStr,
    "BIL " + numStr,
    "BIL. " + numStr,
    numStr
  ];

  // 1. Padanan Tepat
  for (var c = 0; c < headerBaris.length; c++) {
    var val = String(headerBaris[c] || "").trim().toUpperCase();
    for (var k = 0; k < corakCari.length; k++) {
      if (val === corakCari[k].toUpperCase()) {
        return c + 1; // 1-indexed
      }
    }
  }

  // 2. Padanan Mengandungi Nombor Minggu
  for (var c = 0; c < headerBaris.length; c++) {
    var val = String(headerBaris[c] || "").trim().toUpperCase();
    if (val.includes("MINGGU") || val.includes("PERJUMPAAN") || val.includes("M") || val.includes("P")) {
      var digitDalamSel = val.replace(/\D/g, '');
      if (digitDalamSel === numStr) {
        return c + 1;
      }
    }
  }

  return -1;
}

// Dapatkan atau Cipta Lajur Minggu Secara Automatik jika belum wujud
function dapatkanAtauCiptaLajurMinggu(sheet, headerRowIdx, mingguKe) {
  var data = sheet.getDataRange().getDisplayValues();
  var header = data[headerRowIdx] || [];
  var targetCol = cariLajurMinggu(header, mingguKe);
  if (targetCol !== -1) return targetCol;

  // Jika tiada pada baris header semasa, semak baris 0 atau baris 1
  if (headerRowIdx > 0) {
    targetCol = cariLajurMinggu(data[0], mingguKe);
    if (targetCol !== -1) return targetCol;
  }

  // Jika belum wujud, cipta lajur baharu di penghujung helaian
  var newCol = Math.max(sheet.getLastColumn() + 1, 4);
  var labelHeader = "M" + mingguKe;
  sheet.getRange(headerRowIdx + 1, newCol).setValue(labelHeader);
  sheet.getRange(headerRowIdx + 1, newCol).setFontWeight("bold").setHorizontalAlignment("center");
  return newCol;
}

// Ambil Senarai Murid dan Semak Status Kehadiran Minggu Terpilih
// Menggunakan .getDisplayValues() untuk memelihara teks mentah tanpa masalah Date zon masa
// Ambil Senarai Murid dan Semak Status Kehadiran Minggu Terpilih
// Menggunakan .getDisplayValues() untuk memelihara teks mentah tanpa masalah Date zon masa
function getSenaraiMurid(tabName, mingguKe) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(tabName);
    
    // 1. Jika helaian wujud dalam spreadsheet, baca data sebenar daripada helaian guru
    if (sheet) {
      var data = sheet.getDataRange().getDisplayValues();
      if (data && data.length >= 2) {
        // Pengesanan Lajur Nama & Kelas secara dinamik
        var colNama = 1;      // Default: Lajur B (indeks 1)
        var colKelas = 2;     // Default: Lajur C (indeks 2)
        var headerRowIdx = 1; // Default: Baris 2 (indeks 1)

        // Imbas 4 baris teratas untuk mengenal pasti struktur jadual
        for (var r = 0; r < Math.min(data.length, 4); r++) {
          for (var c = 0; c < data[r].length; c++) {
            var val = String(data[r][c] || "").trim().toUpperCase();
            if (val === "NAMA" || val === "NAMA AHLI" || val === "NAMA MURID" || val.includes("NAMA")) {
              colNama = c;
              headerRowIdx = r;
            }
            if (val === "KELAS" || val === "TAHUN" || val.includes("KELAS")) {
              colKelas = c;
            }
          }
        }

        var rowMula = headerRowIdx + 1;

        // Cari lajur minggu / perjumpaan yang dipilih jika dibekalkan
        var colMinggu = -1;
        if (mingguKe) {
          colMinggu = cariLajurMinggu(data[headerRowIdx], mingguKe);
          if (colMinggu === -1 && headerRowIdx > 0) {
            colMinggu = cariLajurMinggu(data[0], mingguKe);
          }
        }

        var senarai = [];
        var noBil = 1;

        for (var i = rowMula; i < data.length; i++) {
          var namaMurid = data[i][colNama] ? data[i][colNama].trim() : "";
          var kelasMurid = data[i][colKelas] ? data[i][colKelas].trim() : "PPKI";

          // Abaikan baris kosong, baris tajuk, atau baris jumlah
          if (namaMurid !== "" && 
              !namaMurid.toUpperCase().startsWith("NAMA") && 
              !namaMurid.toUpperCase().startsWith("JUMLAH") && 
              !namaMurid.toUpperCase().startsWith("CATATAN")) {

            var statusHadir = 1; // Default ditandakan hadir
            if (colMinggu !== -1 && (colMinggu - 1) < data[i].length) {
              var valTeks = String(data[i][colMinggu - 1] || "").trim();
              if (valTeks === "0") {
                statusHadir = 0;
              } else if (valTeks === "1") {
                statusHadir = 1;
              }
            }

            senarai.push({
              bil: noBil++,
              nama: namaMurid,
              kelas: kelasMurid,
              hadir: statusHadir
            });
          }
        }

        if (senarai.length > 0) {
          return senarai;
        }
      }
    }

    // 2. Fallback Data Simulasi: Jika helaian belum diisi atau mod ujian
    var tabUpper = String(tabName || "").toUpperCase();
    if (tabUpper.includes("PPKI")) {
      // Senarai penuh 31 murid MBK PPKI SK Sook
      return [
        { bil: 1, nama: "ALFINO JOELLEMY", kelas: "PPKI", hadir: 1 },
        { bil: 2, nama: "AQIL AMSYAR BIN SAMLI", kelas: "PPKI", hadir: 1 },
        { bil: 3, nama: "CHANTHEL BINTI YUSERY", kelas: "PPKI", hadir: 1 },
        { bil: 4, nama: "DAMIAH ENSYERA REMADANI BINTI LASLIE", kelas: "PPKI", hadir: 1 },
        { bil: 5, nama: "HANS HANIEL BIN HERTIN", kelas: "PPKI", hadir: 1 },
        { bil: 6, nama: "JERERENDY STEPANUS", kelas: "PPKI", hadir: 1 },
        { bil: 7, nama: "LEZNY BAIROL", kelas: "PPKI", hadir: 1 },
        { bil: 8, nama: "MAZARUL BIN JAFRY", kelas: "PPKI", hadir: 1 },
        { bil: 9, nama: "MIA CALLYSTA CAROLUS", kelas: "PPKI", hadir: 1 },
        { bil: 10, nama: "MUHAMMAD AFIE BIN AZRI", kelas: "PPKI", hadir: 1 },
        { bil: 11, nama: "SHERILYN KAYLA SUMIL", kelas: "PPKI", hadir: 1 },
        { bil: 12, nama: "VENNIELSON", kelas: "PPKI", hadir: 1 },
        { bil: 13, nama: "VENTE LARRY CHRISTIANUS", kelas: "PPKI", hadir: 1 },
        { bil: 14, nama: "WILMAH RUSIP", kelas: "PPKI", hadir: 1 },
        { bil: 15, nama: "ALCIE ALCIANIE KHIONG KEM", kelas: "PPKI", hadir: 1 },
        { bil: 16, nama: "CLAUDIA JUKLENEDION GANSAU", kelas: "PPKI", hadir: 1 },
        { bil: 17, nama: "DEVONNE AKIBLEE DONEYSIUSLEE", kelas: "PPKI", hadir: 1 },
        { bil: 18, nama: "HERALD NOEL VICTOR", kelas: "PPKI", hadir: 1 },
        { bil: 19, nama: "IESYA SYAZIRA BINTI NILTER", kelas: "PPKI", hadir: 1 },
        { bil: 20, nama: "IRDINA DELISHA BINTI SYAHRULILHAM", kelas: "PPKI", hadir: 1 },
        { bil: 21, nama: "TERRA ROSSA TONNY", kelas: "PPKI", hadir: 1 },
        { bil: 22, nama: "ZAHADAN ADHAN BIN ZAHARI", kelas: "PPKI", hadir: 1 },
        { bil: 23, nama: "ZANDRAAQILA FEDLIZULEDDY", kelas: "PPKI", hadir: 1 },
        { bil: 24, nama: "CHRISPIONLE JEALIS", kelas: "PPKI", hadir: 1 },
        { bil: 25, nama: "FARRELLEY ANDY LESTER ELLON", kelas: "PPKI", hadir: 1 },
        { bil: 26, nama: "HEALVYANDREY HEALTHER HEADARIAN", kelas: "PPKI", hadir: 1 },
        { bil: 27, nama: "LEO LYJEL JEROME", kelas: "PPKI", hadir: 1 },
        { bil: 28, nama: "PATRONELLA IVY FREDOLINE VU", kelas: "PPKI", hadir: 1 },
        { bil: 29, nama: "RANDELL EVERARD MELOGY", kelas: "PPKI", hadir: 1 },
        { bil: 30, nama: "SUMMERILO SUDALI", kelas: "PPKI", hadir: 1 },
        { bil: 31, nama: "WILSON BIN ABDULLAH", kelas: "PPKI", hadir: 1 }
      ];
    }

    // Default mainstream
    return [
      { bil: 1, nama: "MOHD ALIF BIN ABDULLAH", kelas: "4 UMS", hadir: 1 },
      { bil: 2, nama: "NUR FARISHA BINTI ISMAIL", kelas: "4 USM", hadir: 1 },
      { bil: 3, nama: "ADAM RAYYAN BIN ROSLI", kelas: "5 UPM", hadir: 1 },
      { bil: 4, nama: "SITI NURHALIZA BINTI JUSOH", kelas: "5 USM", hadir: 0 },
      { bil: 5, nama: "DANISH HAIKAL BIN KAMARUL", kelas: "6 UPM", hadir: 1 },
      { bil: 6, nama: "MOHD KHAIRUL BIN ANUAR", kelas: "5 UUM", hadir: 1 },
      { bil: 7, nama: "NURUL AINA BINTI ZAKARIA", kelas: "6 USM", hadir: 1 }
    ];
  } catch (err) {
    console.error("Ralat ambil senarai murid: " + err.message);
    return [];
  }
}

// Alias untuk keserasian panggilan sedia ada
function getSenaraiMuridKokum(kategori, tabName, mingguKe) {
  return getSenaraiMurid(tabName, mingguKe);
}

// --------------------------------------------------------------------------
// 3. PENYIMPANAN KEHADIRAN (WRITE) & PEMFORMATAN BERSYARAT (1=Hijau, 0=Merah)
// --------------------------------------------------------------------------

// Pasang Peraturan Pemformatan Bersyarat (Conditional Formatting) Automatik pada Google Sheets
// Nilai 1 -> Latar Belakang HIJAU lembut (#dcfce7), Teks Hijau Gelap (#15803d)
// Nilai 0 -> Latar Belakang MERAH lembut (#fee2e2), Teks Merah Gelap (#b91c1c)
function pasangConditionalFormattingKoko(sheet, colIndex, startRow, numRows) {
  try {
    var range = sheet.getRange(startRow, colIndex, numRows, 1);
    var rules = sheet.getConditionalFormatRules();
    
    var ruleHadirWujud = false;
    var ruleTidakHadirWujud = false;

    for (var i = 0; i < rules.length; i++) {
      var r = rules[i];
      var cond = r.getBooleanCondition();
      if (cond && cond.getCriteriaType() === SpreadsheetApp.BooleanCriteria.NUMBER_EQUAL_TO) {
        var args = cond.getCriteriaValues();
        if (args && args[0] == 1) ruleHadirWujud = true;
        if (args && args[0] == 0) ruleTidakHadirWujud = true;
      }
    }

    if (!ruleHadirWujud) {
      var ruleHadir = SpreadsheetApp.newConditionalFormatRule()
        .whenNumberEqualTo(1)
        .setBackground("#dcfce7") // Hijau lembut
        .setFontColor("#15803d")   // Teks hijau gelap
        .setBold(true)
        .setRanges([range])
        .build();
      rules.push(ruleHadir);
    }

    if (!ruleTidakHadirWujud) {
      var ruleTidakHadir = SpreadsheetApp.newConditionalFormatRule()
        .whenNumberEqualTo(0)
        .setBackground("#fee2e2") // Merah lembut
        .setFontColor("#b91c1c")   // Teks merah gelap
        .setBold(true)
        .setRanges([range])
        .build();
      rules.push(ruleTidakHadir);
    }

    sheet.setConditionalFormatRules(rules);
  } catch (e) {
    console.warn("Ralat pasang conditional formatting: " + e.message);
  }
}

// Simpan Kehadiran Koko Pukal: Mengemas kini lajur minggu dan menetapkan warna 1=Hijau, 0=Merah
function simpanKehadiranKoko(tabName, mingguKe, dataKehadiran) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(tabName);

    if (!sheet) {
      throw new Error("Tab unit '" + tabName + "' tidak dijumpai dalam Google Sheets.");
    }

    var data = sheet.getDataRange().getDisplayValues();
    if (data.length < 2) {
      throw new Error("Format tab '" + tabName + "' tidak lengkap.");
    }

    // Kenal pasti baris header & lajur nama
    var colNama = 1;
    var headerRowIdx = 1;

    for (var r = 0; r < Math.min(data.length, 3); r++) {
      for (var c = 0; c < data[r].length; c++) {
        var val = String(data[r][c] || "").trim().toUpperCase();
        if (val === "NAMA" || val === "NAMA AHLI" || val === "NAMA MURID" || val.includes("NAMA")) {
          colNama = c;
          headerRowIdx = r;
          break;
        }
      }
    }

    // Dapatkan atau cipta lajur minggu secara automatik
    var targetCol = dapatkanAtauCiptaLajurMinggu(sheet, headerRowIdx, mingguKe);

    // Petakan setiap nama murid kepada nombor baris dalam helaian (1-indexed)
    var mapNamaKeBaris = {};
    for (var r = headerRowIdx + 1; r < data.length; r++) {
      if (data[r][colNama]) {
        var nNorm = String(data[r][colNama]).trim().toUpperCase();
        mapNamaKeBaris[nNorm] = r + 1;
      }
    }

    var jumlahDikemaskini = 0;
    var rowMin = 999999;
    var rowMax = 0;

    // Catatkan nilai 1 atau 0 serta warna sel secara langsung
    dataKehadiran.forEach(function(item) {
      var nCari = String(item.nama || "").trim().toUpperCase();
      var baris = mapNamaKeBaris[nCari];

      if (baris) {
        var nilaiAngka = (item.hadir === true || item.hadir === 1 || item.hadir === "1") ? 1 : 0;
        var cell = sheet.getRange(baris, targetCol);
        
        cell.setValue(nilaiAngka);
        cell.setHorizontalAlignment("center");
        cell.setFontWeight("bold");

        // Warna Latar Lembut: Hijau (#dcfce7) untuk 1, Merah (#fee2e2) untuk 0
        if (nilaiAngka === 1) {
          cell.setBackground("#dcfce7");
          cell.setFontColor("#15803d");
        } else {
          cell.setBackground("#fee2e2");
          cell.setFontColor("#b91c1c");
        }

        if (baris < rowMin) rowMin = baris;
        if (baris > rowMax) rowMax = baris;
        jumlahDikemaskini++;
      }
    });

    // Pasangkan juga Conditional Formatting Rule pada lajur tersebut
    if (rowMin <= rowMax) {
      var totalBaris = (rowMax - rowMin) + 1;
      pasangConditionalFormattingKoko(sheet, targetCol, rowMin, totalBaris);
    }

    return {
      status: "SUCCESS",
      jumlahDikemaskini: jumlahDikemaskini,
      pesanan: `Kehadiran ${jumlahDikemaskini} orang murid bagi ${tabName} (Minggu ${mingguKe}) berjaya disimpan!`
    };
  } catch (err) {
    throw new Error("Ralat simpan kehadiran: " + err.message);
  }
}

// Alias untuk keserasian panggilan sedia ada
function simpanKehadiranKokumPukalBackend(kategori, tabNama, mingguKe, senaraiKehadiran) {
  return simpanKehadiranKoko(tabNama, mingguKe, senaraiKehadiran);
}

// Simpan kehadiran individu (Fallback)
function simpanKehadiranKokumBackend(kategori, tabNama, namaMurid, mingguKe, statusHadir) {
  var nilai = (statusHadir === true || statusHadir === 1 || statusHadir === "1") ? 1 : 0;
  return simpanKehadiranKoko(tabNama, mingguKe, [{ nama: namaMurid, hadir: nilai }]);
}

// --------------------------------------------------------------------------
// 4. MODUL LAPORAN OPR KOKURIKULUM (ONE PAGE REPORT)
// --------------------------------------------------------------------------

// Janaan Teks Automatik bagi 5 Teras OPR Kokurikulum
function janaKandunganOPRKokum(tajuk, unit) {
  var tUpper = String(tajuk || "").toUpperCase();
  var uUpper = String(unit || "").toUpperCase();
  
  var obj1 = "Mendedahkan murid kepada pengetahuan dan kemahiran asas mengenai " + (tajuk || "aktiviti unit") + ".";
  var obj2 = "Meningkatkan tahap disiplin, kepimpinan dan semangat berpasukan dalam kalangan ahli.";
  var obj3 = "Memupuk nilai jati diri, keberanian serta penglibatan aktif semua murid.";
  
  var langkah1 = "Guru penasihat memberi penerangan konsep, taklimat keselamatan dan demonstrasi aktiviti.";
  var langkah2 = "Murid dibahagikan kepada kumpulan kecil bagi sesi amali dan latihan berpandu.";
  var langkah3 = "Setiap kumpulan melaksanakan tugasan secara bergilir-gilir di bawah bimbingan guru penasihat.";
  var langkah4 = "Sesi rumusan aktiviti, refleksi murid dan maklum balas guru bertugas.";
  
  var impak1 = "Majoriti murid berjaya menguasai kemahiran yang dipelajari dengan yakin dan selamat.";
  var impak2 = "Kehadiran dan kerjasama murid amat memuaskan serta menunjukkan minat mendalam.";
  var impak3 = "Disiplin dan adab murid sepanjang perjumpaan terkawal dan mematuhi peraturan.";
  
  var isu1 = "Segelintir murid memerlukan bimbingan secara individu bagi menguasai teknik secara teliti.";
  var isu2 = "Kekangan masa dan giliran peralatan memerlukan susunan stesen yang lebih terperinci.";
  
  var tind1 = "Mengadakan bimbingan rakan sebaya (peer coaching) bersama AJK murid senior.";
  var tind2 = "Menambah bilangan stesen amali agar masa menunggu dapat dikurangkan pada perjumpaan seterusnya.";

  // Penyesuaian khusus mengikut kata kunci topik
  if (tUpper.includes("IKATAN") || tUpper.includes("SIMPULAN") || tUpper.includes("BUKU SILA")) {
    obj1 = "Mendedahkan murid kepada teknik ikatan asas dan simpulan buku sila dengan kaedah yang betul.";
    langkah2 = "Latihan amali mengikat tali secara berpasangan dengan bimbingan guru dan demonstrasi visual.";
    impak1 = "Murid mampu menghasilkan ikatan buku sila dan bunga geti dengan kemas dan pantas.";
  } else if (tUpper.includes("KAWAD") || tUpper.includes("PERBARISAN")) {
    obj1 = "Meningkatkan disiplin, keseragaman pergerakan kawad statik dan kawad dinamik murid.";
    langkah2 = "Latihan kawad kaki mengikut arahan hukuman: sedia, senang diri, luruskan barisan dan pusing.";
    impak1 = "Keseragaman langkah dan keyakinan murid memberi arahan hukuman kawad semakin mantap.";
  } else if (tUpper.includes("PERTOLONGAN") || tUpper.includes("BALUTAN") || tUpper.includes("ANDUH")) {
    obj1 = "Memberi pendedahan praktikal berkenaan prinsip pertolongan cemas dan rawatan awal kecederaan.";
    langkah2 = "Sesi amali menggunakan kain anduh untuk balutan kepala, lengan dan tapak tangan.";
    impak1 = "Murid memahami prosedur keselamatan asas dan cara menggunakan peti pertolongan cemas.";
  } else if (tUpper.includes("BOLA") || tUpper.includes("TAKRAW") || tUpper.includes("BADMINTON") || tUpper.includes("OLAHRAGA")) {
    obj1 = "Menguasai teknik asas kemahiran permainan, kawalan bola/raket dan ketahanan fizikal.";
    langkah2 = "Sesi pemanasan badan, latihan tubi hantaran/pukulan/kawalan dan simulasi permainan kecil.";
    impak1 = "Murid dapat mengaplikasikan undang-undang asas permainan dan memupuk semangat kesukanan.";
  } else if (tUpper.includes("STEM") || tUpper.includes("SAINS") || tUpper.includes("ROBOTIK")) {
    obj1 = "Merangsang daya pemikiran kritis, kreativiti dan penyelesaian masalah melalui projek STEM ringkas.";
    langkah2 = "Aktiviti penerokaan sains secara amali dalam kumpulan menggunakan bahan kitar semula / modul.";
    impak1 = "Murid berupaya membina prototaip dan menerangkan prinsip saintifik di sebalik projek.";
  }

  return {
    objektif: "1. " + obj1 + "\n2. " + obj2 + "\n3. " + obj3,
    pengisian: "1. " + langkah1 + "\n2. " + langkah2 + "\n3. " + langkah3 + "\n4. " + langkah4,
    impak: "1. " + impak1 + "\n2. " + impak2 + "\n3. " + impak3,
    isu: "1. " + isu1 + "\n2. " + isu2,
    tindakan: "1. " + tind1 + "\n2. " + tind2
  };
}

// Simpan Laporan OPR Kokurikulum ke Tab LAPORAN_KOKUM
function simpanPelaporanKokumBackend(formData) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName("LAPORAN_KOKUM");
    
    if (!sheet) {
      sheet = ss.insertSheet("LAPORAN_KOKUM");
      sheet.appendRow([
        "Tarikh Simpan", 
        "Unit Kokurikulum", 
        "Tarikh Perjumpaan",
        "Minggu",
        "Tempat", 
        "Hadir Ahli", 
        "Guru Penasihat", 
        "Tajuk Aktiviti", 
        "Objektif", 
        "Pengisian Aktiviti", 
        "Impak Murid",
        "Isu / Cabaran",
        "Tindakan Susulan",
        "Pautan Gambar 1",
        "Pautan Gambar 2"
      ]);
      sheet.getRange(1, 1, 1, 15).setFontWeight("bold").setBackground("#f1f5f9");
    }

    var urlG1 = formData.gambar1Url || "";
    var urlG2 = formData.gambar2Url || "";
    if (formData.gambar1 && String(formData.gambar1).startsWith("data:")) {
      if (typeof simpanFailKeDrive === 'function') {
        urlG1 = simpanFailKeDrive(formData.gambar1, "KOKU_G1_" + (formData.unit || "UNIT") + ".jpg");
      }
    }
    if (formData.gambar2 && String(formData.gambar2).startsWith("data:")) {
      if (typeof simpanFailKeDrive === 'function') {
        urlG2 = simpanFailKeDrive(formData.gambar2, "KOKU_G2_" + (formData.unit || "UNIT") + ".jpg");
      }
    }
    
    sheet.appendRow([
      new Date(),
      formData.unit || "",
      formData.tarikh || "",
      formData.minggu || "",
      formData.tempat || "",
      Number(formData.hadirAhli) || 0,
      formData.guruHadir || "",
      formData.tajuk || "",
      formData.objektif || formData.setInduksi || "",
      formData.pengisian || "",
      formData.impak || "",
      formData.isu || "",
      formData.tindakan || formData.ulasan || "",
      urlG1,
      urlG2
    ]);

    // Segerakkan ke pangkalan data berpusat LAPORAN_OPR untuk Aliran Kerja Pengesahan Digital & Bank OPR
    if (typeof simpanAtauKemasKiniOpr === 'function') {
      try {
        simpanAtauKemasKiniOpr({
          bahagian: "KOKURIKULUM",
          unit: formData.unit || "Unit Kokurikulum",
          namaProgram: formData.tajuk || "Aktiviti Mingguan Kokurikulum",
          penyelaras: formData.guruHadir || "-",
          emelPenyelaras: formData.emelGuru || "",
          tarikh: formData.tarikh || "",
          masa: formData.minggu ? ("Minggu " + formData.minggu) : "-",
          tempat: formData.tempat || "-",
          kehadiran: formData.hadirAhli || "0",
          objektif: formData.objektif || formData.setInduksi || "",
          pengisian: formData.pengisian || "",
          impak: formData.impak || "",
          isu: formData.isu || "",
          tindakan: formData.tindakan || formData.ulasan || "",
          gambar1Url: urlG1,
          gambar2Url: urlG2
        });
      } catch (eSync) {
        console.warn("Ralat segerak ke LAPORAN_OPR: " + eSync.message);
      }
    }
    
    return { 
      status: "SUCCESS", 
      pesanan: "Laporan OPR Kokurikulum bagi " + (formData.unit || "unit") + " berjaya disimpan ke tab LAPORAN_KOKUM!",
      gambar1Url: urlG1,
      gambar2Url: urlG2
    };
  } catch (err) {
    throw new Error("Ralat menyimpan laporan OPR kokum: " + err.message);
  }
}

// Penjanaan PDF OPR Kokurikulum (A4 Portrait - 1 Muka Surat)
function janaPdfOprKokumBackend(formData) {
  try {
    var unit = formData.unit || "UNIT KOKURIKULUM";
    var tajuk = formData.tajuk || "AKTIVITI PERJUMPAAN KOKURIKULUM";
    var tarikh = formData.tarikh || "-";
    var minggu = formData.minggu ? ("Minggu " + formData.minggu) : "-";
    var tempat = formData.tempat || "Kawasan Sekolah";
    var hadir = formData.hadirAhli || "0";
    var guru = formData.guruHadir || "Guru Penasihat";
    var objektif = formData.objektif || "-";
    var pengisian = formData.pengisian || "-";
    var impak = formData.impak || "-";
    var isu = formData.isu || "-";
    var tindakan = formData.tindakan || "-";
    var g1 = formData.gambar1 || formData.gambar1Url || "";
    var g2 = formData.gambar2 || formData.gambar2Url || "";

    // Tukar pautan gambar Google Drive kepada Base64 Data URI untuk pemaparan PDF selamat
    if (g1 && !String(g1).startsWith("data:image") && typeof ambilBase64DariDrive === 'function') {
      var b64_1 = ambilBase64DariDrive(g1);
      if (b64_1) g1 = b64_1;
    }
    if (g2 && !String(g2).startsWith("data:image") && typeof ambilBase64DariDrive === 'function') {
      var b64_2 = ambilBase64DariDrive(g2);
      if (b64_2) g2 = b64_2;
    }

    function formatPointsHtml(text) {
      if (!text) return '-';
      var lines = String(text).split('\n').filter(function(l){ return l.trim() !== ''; });
      if (lines.length <= 1) return String(text).replace(/\n/g, '<br>');
      return lines.map(function(l){ return '<div style="margin-bottom:2px;">' + l + '</div>'; }).join('');
    }

    var img1Html = g1 ? '<div style="text-align:center; flex:1; padding:3px; border:1px solid #e2e8f0; border-radius:6px; background:#fff;"><img src="' + g1 + '" style="max-height:120px; max-width:100%; object-fit:cover; border-radius:4px;" /><div style="font-size:8px; color:#64748b; margin-top:2px; font-weight:bold;">Gambar 1: Semasa Aktiviti</div></div>' : '<div style="flex:1; border:1px dashed #cbd5e1; border-radius:6px; height:100px; display:flex; align-items:center; justify-content:center; color:#94a3b8; font-size:8.5px; background:#f8fafc;">[Tiada Gambar 1]</div>';
    
    var img2Html = g2 ? '<div style="text-align:center; flex:1; padding:3px; border:1px solid #e2e8f0; border-radius:6px; background:#fff;"><img src="' + g2 + '" style="max-height:120px; max-width:100%; object-fit:cover; border-radius:4px;" /><div style="font-size:8px; color:#64748b; margin-top:2px; font-weight:bold;">Gambar 2: Penglibatan Ahli</div></div>' : '<div style="flex:1; border:1px dashed #cbd5e1; border-radius:6px; height:100px; display:flex; align-items:center; justify-content:center; color:#94a3b8; font-size:8.5px; background:#f8fafc;">[Tiada Gambar 2]</div>';

    var htmlContent = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>OPR Kokurikulum - ${unit}</title>
  <style>
    @page { size: A4 portrait; margin: 8mm 10mm 8mm 10mm; }
    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 9px; color: #1e293b; margin: 0; line-height: 1.3; }
    .header-table { width: 100%; border-bottom: 2px solid #1e3a8a; padding-bottom: 4px; margin-bottom: 6px; }
    .title-main { font-size: 12px; font-weight: 800; color: #1e3a8a; text-transform: uppercase; }
    .title-sub { font-size: 9px; font-weight: 700; color: #475569; }
    .info-grid { width: 100%; border-collapse: collapse; margin-bottom: 6px; font-size: 8.5px; }
    .info-grid td { border: 1px solid #cbd5e1; padding: 3.5px 6px; vertical-align: top; }
    .info-lbl { font-weight: bold; background-color: #f8fafc; color: #334155; width: 18%; }
    .info-val { font-weight: 600; color: #0f172a; width: 32%; }
    .section-box { border: 1px solid #cbd5e1; border-radius: 5px; margin-bottom: 5px; overflow: hidden; }
    .section-title { background: #f1f5f9; font-weight: 800; color: #1e293b; padding: 3px 6px; font-size: 8.5px; border-bottom: 1px solid #cbd5e1; text-transform: uppercase; }
    .section-content { padding: 4px 6px; font-size: 8.5px; color: #1e293b; }
    .footer-table { width: 100%; margin-top: 8px; border-collapse: collapse; font-size: 8px; }
    .footer-table td { width: 50%; vertical-align: top; }
  </style>
</head>
<body>
  <table class="header-table">
    <tr>
      <td style="width: 50px; text-align: center; vertical-align: middle;">
        ${typeof dapatkanLogoSekolah === 'function' && dapatkanLogoSekolah() ? 
          '<img src="' + dapatkanLogoSekolah() + '" style="max-height:45px; max-width:45px; object-fit:contain;" alt="Lencana SK Sook" />' : 
          '<div style="font-size: 24px;">🏫</div>'}
      </td>
      <td style="vertical-align: middle;">
        <div class="title-main">SEKOLAH KEBANGSAAN SOOK, KENINGAU</div>
        <div class="title-sub">LAPORAN SATU MUKA SURAT (ONE PAGE REPORT - OPR) KOKURIKULUM</div>
        <div style="font-size: 7.5px; color: #64748b;">Peti Surat 204, 89008 Keningau, Sabah • Kod Sekolah: XBA1026</div>
      </td>
    </tr>
  </table>

  <table class="info-grid">
    <tr>
      <td class="info-lbl">UNIT KOKURIKULUM</td>
      <td class="info-val">${unit}</td>
      <td class="info-lbl">PERJUMPAAN / MINGGU</td>
      <td class="info-val">${minggu}</td>
    </tr>
    <tr>
      <td class="info-lbl">TARIKH & MASA</td>
      <td class="info-val">${tarikh}</td>
      <td class="info-lbl">TEMPAT PELAKSANAAN</td>
      <td class="info-val">${tempat}</td>
    </tr>
    <tr>
      <td class="info-lbl">GURU PENASIHAT</td>
      <td class="info-val">${guru}</td>
      <td class="info-lbl">KEHADIRAN AHLI</td>
      <td class="info-val"><strong>${hadir} Orang Murid</strong></td>
    </tr>
    <tr>
      <td class="info-lbl">TAJUK / TOPIK</td>
      <td class="info-val" colspan="3" style="font-size: 9px; color: #1e3a8a; font-weight: 800;">${tajuk}</td>
    </tr>
  </table>

  <div class="section-box">
    <div class="section-title">1. OBJEKTIF PERJUMPAAN</div>
    <div class="section-content">${formatPointsHtml(objektif)}</div>
  </div>

  <div class="section-box">
    <div class="section-title">2. PENGISIAN & RINGKASAN AKTIVITI</div>
    <div class="section-content">${formatPointsHtml(pengisian)}</div>
  </div>

  <div class="section-box">
    <div class="section-title">3. IMPAK & KEBERHASILAN MURID</div>
    <div class="section-content">${formatPointsHtml(impak)}</div>
  </div>

  <table style="width:100%; border-collapse:collapse; margin-bottom:5px;">
    <tr>
      <td style="width:49.5%; vertical-align:top; padding-right:3px;">
        <div class="section-box" style="margin-bottom:0;">
          <div class="section-title" style="background:#fff1f2; color:#9f1239; border-color:#fecdd3;">4. ISU & CABARAN</div>
          <div class="section-content" style="min-height:30px;">${formatPointsHtml(isu)}</div>
        </div>
      </td>
      <td style="width:49.5%; vertical-align:top; padding-left:3px;">
        <div class="section-box" style="margin-bottom:0;">
          <div class="section-title" style="background:#f0fdf4; color:#166534; border-color:#bbf7d0;">5. TINDAKAN SUSULAN</div>
          <div class="section-content" style="min-height:30px;">${formatPointsHtml(tindakan)}</div>
        </div>
      </td>
    </tr>
  </table>

  <div class="section-box" style="margin-bottom:5px;">
    <div class="section-title">6. DOKUMENTASI BERGAMBAR AKTIVITI</div>
    <div class="section-content" style="display:flex; gap:6px; padding:4px;">
      ${img1Html}
      ${img2Html}
    </div>
  </div>

  <table class="footer-table">
    <tr>
      <td style="padding-right: 12px;">
        <div>Disediakan Oleh:</div>
        <div style="height: 24px;"></div>
        <div style="font-weight: bold; border-top: 1px dotted #94a3b8; padding-top: 2px;">${guru.toUpperCase()}</div>
        <div style="color: #64748b;">Guru Penasihat ${unit}</div>
        <div style="color: #64748b;">Tarikh: ${tarikh}</div>
      </td>
      <td style="padding-left: 12px;">
        <div>Disahkan Oleh:</div>
        <div style="height: 24px;"></div>
        <div style="font-weight: bold; border-top: 1px dotted #94a3b8; padding-top: 2px;">PENOLONG KANAN KOKURIKULUM</div>
        <div style="color: #64748b;">SK Sook, Keningau</div>
        <div style="color: #64748b;">Tarikh:</div>
      </td>
    </tr>
  </table>
</body>
</html>`;

    var folderName = "PORTAL_SK_SOOK_PDF";
    var folder;
    try {
      var folders = DriveApp.getFoldersByName(folderName);
      folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(folderName);
    } catch (fErr) {
      folder = DriveApp.getRootFolder();
    }

    var namaFailPdf = "OPR_KOKU_" + unit.replace(/\s+/g, '_') + "_" + (formData.minggu ? ("M" + formData.minggu) : "LAPORAN") + ".pdf";
    var tempFile = DriveApp.createFile("temp_opr_koku.html", htmlContent, MimeType.HTML);
    var pdfBlob = tempFile.getAs(MimeType.PDF).setName(namaFailPdf);
    var pdfFile = folder.createFile(pdfBlob);

    try {
      pdfFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    } catch (errDomain) {
      try { pdfFile.setSharing(DriveApp.Access.DOMAIN_WITH_LINK, DriveApp.Permission.VIEW); } catch (eSub) {}
    }

    var pdfBase64 = Utilities.base64Encode(pdfBlob.getBytes());
    tempFile.setTrashed(true);

    return {
      status: "SUCCESS",
      urlPdf: pdfFile.getUrl(),
      downloadUrl: pdfFile.getUrl().replace('view?usp=drivesdk', 'export?format=pdf'),
      base64: pdfBase64,
      namaFail: namaFailPdf,
      pesanan: "PDF OPR Kokurikulum berjaya dijana!"
    };
  } catch (err) {
    throw new Error("Ralat menjana PDF OPR Kokum: " + err.message);
  }
}
